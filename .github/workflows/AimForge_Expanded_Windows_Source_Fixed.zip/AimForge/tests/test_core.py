import csv
import json
import math
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from aimforge import monitor, storage


class MonitorTests(unittest.TestCase):
    def test_presentmon_csv_fps_metrics(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "capture.csv"
            with path.open("w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["MsBetweenPresents"])
                w.writerows([[10], [20], [10], ["bad"], [0], ["nan"]])
            m = monitor.PerformanceMonitor()
            m.set_csv(str(path))
            m._read_csv()
            self.assertEqual(list(m.samples), [10.0, 20.0, 10.0])
            with patch.object(m, "_nvidia_metrics", return_value={
                "gpu_temp": None, "gpu_usage": None, "vram_used": None,
                "gpu_clock": None, "gpu_power": None,
            }):
                result = m.snapshot()
            self.assertAlmostEqual(result["fps"], 100.0)
            self.assertAlmostEqual(result["avg_fps"], 75.0)
            self.assertAlmostEqual(result["one_percent_low"], 50.0)

    def test_missing_csv_is_safe(self):
        m = monitor.PerformanceMonitor()
        m.set_csv("/path/that/does/not/exist.csv")
        m._read_csv()
        self.assertEqual(len(m.samples), 0)

    def test_nvidia_query_has_valid_field_list(self):
        completed = type("Result", (), {"stdout": "60, 40, 2048, 1800, 120.5\n"})()
        with patch.object(monitor.subprocess, "run", return_value=completed) as run:
            result = monitor.PerformanceMonitor()._nvidia_metrics()
        command = run.call_args.args[0][1]
        self.assertIn("clocks.gr,power.draw", command)
        self.assertEqual(result["gpu_temp"], 60.0)
        self.assertEqual(result["vram_used"], 2.0)


class StorageTests(unittest.TestCase):
    def test_atomic_json_save_and_load(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "nested" / "data.json"
            storage.save(path, {"hello": "AimForge"})
            self.assertEqual(storage.load(path, {}), {"hello": "AimForge"})
            self.assertFalse(path.with_suffix(".json.tmp").exists())

    def test_backup_restore_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            paths = [Path(td) / name for name in ("p.json", "b.json", "s.json")]
            with patch.object(storage, "P", paths[0]), patch.object(storage, "B", paths[1]), patch.object(storage, "S", paths[2]):
                storage.save(paths[0], {"Valorant": {"crosshair": {"style": "Dot"}}})
                storage.save(paths[1], [{"game": "Valorant", "avg_fps": 200}])
                storage.save(paths[2], [{"fps": 200}])
                backup = Path(td) / "backup.json"
                storage.backup(backup)
                storage.save(paths[0], {})
                storage.restore(backup)
                self.assertIn("Valorant", storage.load(paths[0], {}))
                self.assertEqual(len(storage.load(paths[1], [])), 1)

    def test_reject_invalid_backup(self):
        with tempfile.TemporaryDirectory() as td:
            bad = Path(td) / "bad.json"
            bad.write_text("[]", encoding="utf-8")
            with self.assertRaises(ValueError):
                storage.restore(bad)


if __name__ == "__main__":
    unittest.main()
