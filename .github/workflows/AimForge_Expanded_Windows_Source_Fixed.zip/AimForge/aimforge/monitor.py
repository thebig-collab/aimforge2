import csv, os, time, subprocess, math
from collections import deque
import psutil

class PerformanceMonitor:
    def __init__(self):
        self.samples = deque(maxlen=240)
        self.csv_path = None
        psutil.cpu_percent(interval=None)

    def set_csv(self, path):
        self.csv_path = path
        self.samples.clear()

    def _read_csv(self):
        if not self.csv_path or not os.path.isfile(self.csv_path):
            self.samples.clear()
            return
        try:
            keys = ("MsBetweenPresents", "msBetweenPresents",
                    "MsBetweenDisplayChange", "msBetweenDisplayChange")
            recent = deque(maxlen=240)
            with open(self.csv_path, encoding="utf-8-sig", newline="") as f:
                for row in csv.DictReader(f):
                    key = next((k for k in keys if k in row), None)
                    if key:
                        try:
                            ms = float(row[key])
                            if math.isfinite(ms) and 0.05 <= ms <= 1000:
                                recent.append(ms)
                        except (ValueError, TypeError):
                            continue
            self.samples.clear()
            self.samples.extend(recent)
        except (OSError, csv.Error):
            self.samples.clear()

    def _nvidia_metrics(self):
        # NVIDIA telemetry is available when the vendor driver exposes nvidia-smi.
        try:
            r=subprocess.run(["nvidia-smi","--query-gpu=temperature.gpu,utilization.gpu,memory.used,clocks.gr,power.draw","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=2,check=True)
            line = next((line for line in r.stdout.splitlines() if line.strip()), "")
            parts=[x.strip() for x in line.split(",")]
            if len(parts) < 5 or any(x in ("[Not Supported]", "N/A", "") for x in parts[:5]):
                raise ValueError("Incomplete NVIDIA telemetry")
            values=[float(x) for x in parts[:5]]
            return {"gpu_temp":values[0],"gpu_usage":values[1],"vram_used":values[2]/1024,"gpu_clock":values[3],"gpu_power":values[4]}
        except Exception: return {"gpu_temp":None,"gpu_usage":None,"vram_used":None,"gpu_clock":None,"gpu_power":None}

    def snapshot(self):
        self._read_csv()
        fps = avg = low = None
        if self.samples:
            vals = list(self.samples)
            fps = 1000.0 / vals[-1]
            avg = len(vals) * 1000.0 / sum(vals)
            ordered = sorted(1000.0 / x for x in vals)
            low = sum(ordered[:max(1, (len(ordered)+99)//100)]) / max(1, (len(ordered)+99)//100)
        vm = psutil.virtual_memory()
        gpu=self._nvidia_metrics()
        return {"fps":fps, "avg_fps":avg, "one_percent_low":low,
                "cpu_usage":psutil.cpu_percent(interval=None),
                "ram_used_gb":(vm.total-vm.available)/1024**3,
                "ram_total_gb":vm.total/1024**3, "timestamp":time.time(),
                "cpu_temp":None, **gpu, "cpu_clock":None}
