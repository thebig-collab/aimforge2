from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QPainter, QPen, QColor, QBrush
from PySide6.QtWidgets import QWidget

class CrosshairOverlay(QWidget):
    SHAPES = ["Classic", "Dot", "Circle", "Cross", "T-Shape", "X", "Square", "Diamond", "Hollow Square", "Plus Dot", "Circle Dot", "Tight Cross", "Chevron", "Triangle"]
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AimForge Crosshair")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.size_px, self.gap, self.thickness = 18, 5, 2
        self.opacity, self.color, self.style = 1.0, QColor("#00ff88"), "Classic"
        self.outline_enabled, self.outline_color, self.outline_width = True, QColor("#101010"), 2
    def configure(self, size_px, gap, thickness, color, opacity, style, outline_enabled=True, outline_color="#101010", outline_width=2):
        self.size_px=max(2,min(100,int(size_px))); self.gap=max(0,min(50,int(gap)))
        self.thickness=max(1,min(12,int(thickness))); self.color=QColor(color)
        self.opacity=max(.1,min(1,float(opacity))); self.style=style
        self.outline_enabled=bool(outline_enabled); self.outline_color=QColor(outline_color); self.outline_width=max(0,min(8,int(outline_width))); self.update()
    def paintEvent(self, event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        x,y=self.width()//2,self.height()//2; s,g=self.size_px,self.gap
        def draw(color, width, fill=False):
            c=QColor(color); c.setAlphaF(self.opacity)
            p.setPen(QPen(c,width,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
            p.setBrush(QBrush(c) if fill else Qt.NoBrush)
            if self.style in ("Dot", "Plus Dot", "Circle Dot"):
                p.drawEllipse(x-self.thickness,y-self.thickness,2*self.thickness,2*self.thickness)
            if self.style in ("Circle", "Circle Dot"):
                p.setBrush(Qt.NoBrush); p.drawEllipse(x-s//2,y-s//2,s,s)
            elif self.style in ("Square", "Hollow Square"):
                p.setBrush(Qt.NoBrush); p.drawRect(x-s//2,y-s//2,s,s)
            elif self.style == "Diamond":
                p.drawPolygon([QPoint(x,y-s//2),QPoint(x+s//2,y),QPoint(x,y+s//2),QPoint(x-s//2,y)])
            elif self.style == "Triangle":
                p.drawPolygon([QPoint(x,y-s//2),QPoint(x+s//2,y+s//2),QPoint(x-s//2,y+s//2)])
            elif self.style == "X":
                p.drawLine(x-s,y-s,x+s,y+s); p.drawLine(x+s,y-s,x-s,y+s)
            elif self.style == "Chevron":
                p.drawLine(x-s,y-s//3,x,y+s//3); p.drawLine(x,y+s//3,x+s,y-s//3)
            elif self.style in ("Classic","Cross","T-Shape","Tight Cross","Plus Dot"):
                p.drawLine(x-s,y,x-g,y); p.drawLine(x+g,y,x+s,y)
                if self.style != "T-Shape": p.drawLine(x,y-s,x,y-g)
                p.drawLine(x,y+g,x,y+s)
        if self.outline_enabled and self.outline_width:
            draw(self.outline_color,self.thickness+2*self.outline_width,False)
        draw(self.color,self.thickness,self.style in ("Dot","Plus Dot"))
