import json
import os
from pathlib import Path
from datetime import datetime


def _data_dir():
    """Return a persistent, user-writable data directory (also safe for PyInstaller)."""
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif os.environ.get("XDG_DATA_HOME"):
        root = Path(os.environ["XDG_DATA_HOME"])
    else:
        root = Path.home() / ".local" / "share"
    path = root / "AimForge"
    path.mkdir(parents=True, exist_ok=True)
    return path


DATA = _data_dir()
P = DATA / "profiles.json"
B = DATA / "benchmarks.json"
S = DATA / "sessions.json"

def load(path, default):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError): return default

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)

def profiles(): return load(P, {})
def benchmarks(): return load(B, [])
def save_profile(name, value):
    items = profiles()
    items[name] = {**value, "updated_at": datetime.now().isoformat(timespec="seconds")}
    save(P, items)
def add_benchmarks(rows):
    items = benchmarks()
    items.extend(rows)
    save(B, items)
def add_session(row):
    items = load(S, [])
    items.append(row)
    save(S, items[-5000:])
def backup(path):
    save(Path(path), {"profiles":profiles(), "benchmarks":benchmarks(), "sessions":load(S,[])})
def restore(path):
    data = load(Path(path), None)
    if not isinstance(data, dict):
        raise ValueError("Backup file is not a valid AimForge backup.")
    profiles_data = data.get("profiles", {})
    benchmarks_data = data.get("benchmarks", [])
    sessions_data = data.get("sessions", [])
    if not isinstance(profiles_data, dict) or not isinstance(benchmarks_data, list) or not isinstance(sessions_data, list):
        raise ValueError("Backup has an invalid data structure.")
    save(P, profiles_data)
    save(B, benchmarks_data)
    save(S, sessions_data[-5000:])
