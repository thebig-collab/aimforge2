# AimForge — Windows Gaming Command Center (expanded source build)

AimForge is a local-first Windows desktop application inspired by the workflow of gaming crosshair utilities. It is an independent design and does not use Crosshair X assets or branding.

## Included features
- Crosshair Studio with 14 shapes, size/gap/thickness/opacity and color controls.
- Toggleable outline with independent outline color and width.
- Transparent always-on-top desktop overlay; `Ctrl+Shift+X` toggles it while the app is focused.
- Local game profiles with save/load and JSON backup/restore.
- Tweak Library with Windows Game Mode preference, High performance power plan, transparency toggle, and shortcuts to Windows Graphics and Startup settings.
- Live monitor: CPU and RAM via psutil; FPS from imported PresentMon CSV; NVIDIA GPU temperature, utilization, VRAM, clock and power when `nvidia-smi` is installed and supported.
- Benchmark CSV import with explicit `measured` / `estimated` labels.
- FPS Estimator using a user-entered comparable measured baseline and transparent resolution/quality scaling. It is a rough estimate, not a component-database guarantee.

## Data storage and verification
- Profiles, benchmark imports and session history are saved persistently under `%LOCALAPPDATA%\AimForge` on Windows (not inside the temporary PyInstaller extraction folder).
- Automated unit tests cover PresentMon CSV parsing, FPS calculations, NVIDIA telemetry parsing, and backup/restore. Run them with `python -m unittest discover -s tests -v`.

## Important measurement limits
- FPS needs a PresentMon CSV capture. AimForge does not inject into games or hook anti-cheat protected processes.
- CPU temperature and some non-NVIDIA GPU sensors are unavailable unless a compatible sensor provider is added. Unsupported metrics show `—`, never fabricated values.
- The FPS estimator is not a live hardware benchmark database. It scales a comparable baseline supplied by the user; game scenes, drivers, cooling and CPU/GPU bottlenecks can materially change results.
- Tweaks are optional and should be reviewed. High performance mode can increase power use and heat. The app does not disable security features, services, or anti-cheat.
- Check the overlay policy of each game and anti-cheat before enabling the overlay.

## Build a no-Python-needed Windows EXE
The EXE is built on a Windows runner using GitHub Actions. No Python installation is needed on the target PC.

1. Upload the contents of this package to a GitHub repository (keep `.github/workflows/build-windows.yml` at repository root and `AimForge/` as a folder).
2. Open **Actions → Build AimForge for Windows → Run workflow**.
3. Download the `AimForge-Windows` artifact. It contains `AimForge.exe` and runs without Python installed on the target PC.

For local developer builds only, run `build_windows.bat` on Windows (requires Python 3.12).

## Benchmark CSV format
Required columns: `game,cpu,gpu,resolution,preset,avg_fps,one_percent_low,source,benchmark_date,kind`; `kind` must be `measured` or `estimated`.
